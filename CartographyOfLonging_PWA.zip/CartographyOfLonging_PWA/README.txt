THE CARTOGRAPHY OF LONGING — installable offline web app
=========================================================
Upload this whole folder to any HTTPS static host (it must be served over https:// — double-clicking index.html won't install).

Fastest (no account needed for a quick test):
  1. Go to https://app.netlify.com/drop
  2. Drag this folder (or CartographyOfLonging_PWA.zip) onto the page.
  3. Open the link it gives you on the phone.

Other free hosts: GitHub Pages, Cloudflare Pages, Vercel — upload the folder contents as-is, keep index.html at the root.

INSTALL ON PHONE
  iPhone / iPad (Safari): open the link, tap Share, then "Add to Home Screen".
  Android (Chrome): open the link, tap "Install app" on the start screen (or menu, then Install app / Add to Home screen).
After the first visit the app is stored on the phone and runs with no internet. It opens full-screen from its own icon.

UPDATING: replace index.html and change VERSION in sw.js (e.g. 'col-v2'); phones pick up the new version on the next open.
Everything (three.js, code, icons) is inside this folder — no external requests.
